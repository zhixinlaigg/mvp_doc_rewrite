# Quickstart: Generate and verify an image's watermark using Imagen text-to-image (Console)

This quickstart shows you how to use Imagen on Vertex AI to generate images from a text prompt and verify the digital watermark ([SynthID](https://deepmind.google/technologies/synthid/)) on a generated image using the Google Cloud console.

For information on pricing, see [Imagen on Vertex AI pricing](https://cloud.google.com/vertex-ai/pricing#generative-ai-models).

<figure style="text-align: center;">
  <img src="images/gen-img-quickstart.png" alt="A generated image of a dog" style="max-width: 100%; border-radius: 8px;">
  <figcaption>Image generated using the prompt: <em>portrait of a french bulldog at the beach, 85mm f/2.8</em>.</figcaption>
</figure>

```mermaid
flowchart LR
    A[Generate images] --> B[Verify watermark] --> C[Clean up]

    click A "#generate-images"
    click B "#verify-watermark"
    click C "#clean-up"
```

## ⚙️ Before you begin
<a name="before-you-begin"></a>

???+ "Before you begin"

    1.  Sign in to your Google Cloud account. If you're new to Google Cloud, [create an account](https://console.cloud.google.com/freetrial) to evaluate how our products perform in real-world scenarios. New customers also get $300 in free credits to run, test, and deploy workloads.
    2.  In the Google Cloud console, on the project selector page, select or create a Google Cloud project.

    **Note**: If you don't plan to keep the resources that you create in this procedure, create a project instead of selecting an existing project. After you finish these steps, you can delete the project, removing all resources associated with the project.

    [Go to project selector](https://console.cloud.google.com/projectselector2/home/dashboard){: .md-button}

    3.  Make sure that billing is enabled for your Google Cloud project.
    4.  Enable the Vertex AI API.

    [Enable the API](https://console.cloud.google.com/flows/enableapi?apiid=aiplatform.googleapis.com){: .md-button}

    !!! tip "Troubleshooting"
        If you encounter issues with the setup, refer to the [Troubleshooting Guide](https://cloud.google.com/vertex-ai/docs/general/troubleshooting?component=any).

## ⚙️ Generate images and save a local copy
<a name="generate-images"></a>

???+ "Steps to generate images and save a local copy"

    Send the text-to-image generation request using the Google Cloud console.

    1.  In the Google Cloud console, open the **Vertex AI Studio > Media** tab in the Vertex AI dashboard.

    [Go to Vertex AI Studio](https://console.cloud.google.com/vertex-ai/studio/media/generate;tab=image){: .md-button}

    2.  In the **Prompt** field, enter the following prompt:

        ```
        portrait of a french bulldog at the beach, 85mm f/2.8
        ```

    3.  If not selected, in the **Model options** box in the **Parameters** panel, select `Imagen 3`.
    4.  If not selected, in the **Aspect ratio** section in the **Parameters** panel, select `1:1`.
    5.  In the **Number of results** section, change the **Number of results** to `2`.
    6.  Click **Generate**.

    Generating images produces results similar to the following:

    <figure style="text-align: center;">
      <img src="images/gen-img-quickstart_output.png" alt="Sample generated images in console" style="max-width: 100%; border-radius: 8px;">
      <figcaption>Sample images generated in the console.</figcaption>
    </figure>

    7.  To save a local copy of an image, click one of the images.
    8.  In the **Image details** window that opens, click **Export**.
    9.  In the **Export image** dialog box, click **Export**.

## ⚙️ Verify an image's digital watermark
<a name="verify-watermark"></a>

???+ "Steps to verify an image's digital watermark"

    After you generate watermarked images, you can verify the digital watermark of the images.

    1.  Generate images and save a local copy as you did in the previous section.
    2.  In the **Image detail** window, click **Export**.
    3.  In the lower panel, click **Verify**.
    4.  Click **Upload image**.
    5.  Select a locally-saved generated image.

    <figure style="text-align: center;">
      <img src="images/quickstart-watermark-detected.png" alt="Sample verified watermark in generated image in console" style="max-width: 100%; border-radius: 8px;">
      <figcaption>A detected watermark in a generated image.</figcaption>
    </figure>

## ⚙️ Clean up
<a name="clean-up"></a>

???+ "Steps to clean up resources"

    To avoid incurring charges to your Google Cloud account for the resources used on this page, delete the project that contains the resources.

    **Caution**: Deleting a project has the following effects:
    *   **Everything in the project is deleted.** If you used an existing project for the tasks in this document, when you delete it, you also delete any other work you've done in the project.
    *   **Custom project IDs are lost.** When you created this project, you might have created a custom project ID that you want to use in the future. To preserve the URLs that use the project ID, such as an `appspot.com` URL, delete selected resources inside the project instead of deleting the whole project.

    If you plan to explore multiple architectures, tutorials, or quickstarts, reusing projects can help you avoid exceeding project quota limits.

    1.  In the Google Cloud console, go to the **Manage resources** page.

    [Go to Manage resources](https://console.cloud.google.com/iam-admin/projects){: .md-button}

    2.  In the project list, select the project that you want to delete, and then click **Delete**.
    3.  In the dialog, type the project ID, and then click **Shut down** to delete the project.

## 🔗 What's next

*   Learn about all image generative AI features in the [Imagen on Vertex AI overview](https://cloud.google.com/vertex-ai/docs/generative-ai/image/overview).
*   To view an overview of the API options for image generation and editing, see the [`imagegeneration` model API reference](https://cloud.google.com/vertex-ai/docs/generative-ai/model-reference/image-generation).
*   Read [usage guidelines for Imagen on Vertex AI](https://cloud.google.com/vertex-ai/docs/generative-ai/image/usage-guidelines).
*   Explore more pretrained models in [Model Garden](https://cloud.google.com/model-garden).
*   Learn about [responsible AI best practices and Vertex AI's safety filters](https://cloud.google.com/vertex-ai/docs/generative-ai/learn/responsible-ai).