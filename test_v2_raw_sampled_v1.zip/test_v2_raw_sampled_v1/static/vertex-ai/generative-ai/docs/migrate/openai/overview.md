# Migrate from OpenAI to Vertex AI

This document provides an overview of how to migrate your existing applications from the OpenAI API to Google Cloud's Vertex AI platform. After you're done with this page, you can explore specific migration paths for chat completions and embeddings.

## 📚 Why migrate from OpenAI to Vertex AI?

While OpenAI provides excellent tools for building generative AI applications, Vertex AI offers a comprehensive, enterprise-ready platform with several key advantages:

*   **Access to Google's Foundation Models**: Leverage powerful models like Gemini and PaLM 2, which are built on Google's extensive research and infrastructure.
*   **Enterprise-Grade Security and Governance**: Benefit from Google Cloud's robust security posture, data privacy commitments, and compliance certifications. Your data is not used for training Google's models and remains under your control.
*   **Integrated MLOps Platform**: Vertex AI is more than just an API. It's a full MLOps platform that supports the entire machine learning lifecycle, from data preparation and model training to deployment and monitoring.
*   **Customization and Grounding**: Fine-tune models with your own data and ground them with enterprise data sources to deliver more accurate and relevant responses.
*   **Cost-Effectiveness**: Vertex AI offers competitive pricing and options to optimize your spending on generative AI workloads.
*   **Ecosystem Integration**: Seamlessly connect with other Google Cloud services like BigQuery, Cloud Storage, and LangChain on Vertex AI for building sophisticated AI-powered workflows.

## ⚙️ How to migrate from OpenAI to Vertex AI

Migrating your application involves updating your code to use either the Vertex AI SDK for Python or the Vertex AI REST API instead of the OpenAI libraries. The core logic of your application—how you handle prompts, responses, and application flow—will likely remain the same.

Before you choose a method, use the following table to compare the Vertex AI SDK and the REST API.

| Feature | Vertex AI SDK for Python | REST API |
| :--- | :--- | :--- |
| **Primary Use Case** | Best for developers working in a Python environment who want a streamlined, high-level interface for interacting with Vertex AI. | Best for developers who need language-agnostic compatibility or want to integrate Vertex AI into non-Python applications or existing REST-based workflows. |
| **Ease of Use** | High. The SDK abstracts away much of the complexity of authentication and API calls. | Moderate. Requires manual handling of API requests, authentication tokens, and response parsing. |
| **Dependencies** | Requires installing the `google-cloud-aiplatform` library in your Python environment. | No client-side dependencies other than an HTTP client (like cURL or `requests`). |
| **Authentication** | Handled automatically if the environment is authenticated (e.g., via `gcloud auth application-default login`). | Requires manually obtaining an access token and including it in the `Authorization` header of each request. |

!!! tip "Troubleshooting"
    If you encounter issues with code snippets or setup, refer to the [Troubleshooting Guide](https://cloud.google.com/vertex-ai/docs/general/troubleshooting?component=any).

=== "Vertex AI SDK for Python"

    **Chat completions**

    The following code shows how to convert an OpenAI chat completion request to a Vertex AI request using the Python SDK.

    ```python
    # pip install openai
    import openai
    openai.api_key = "OPENAI_API_KEY"

    completion = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "user", "content": "What is the purpose of a vector database?"}
        ],
    )

    print(completion.choices[0].message.content)
    ```

    ```python
    # pip install google-cloud-aiplatform
    import vertexai
    from vertexai.language_models import ChatModel

    vertexai.init(project="PROJECT_ID", location="LOCATION")

    chat_model = ChatModel.from_pretrained("chat-bison@002")
    chat = chat_model.start_chat()
    response = chat.send_message("What is the purpose of a vector database?")

    print(response.text)
    ```

    **Embeddings**

    The following code shows how to convert an OpenAI embeddings request to a Vertex AI request using the Python SDK.

    ```python
    # pip install openai
    import openai
    openai.api_key = "OPENAI_API_KEY"

    response = openai.Embedding.create(
        input="What is the purpose of a vector database?",
        model="text-embedding-ada-002",
    )

    print(response["data"][0]["embedding"])
    ```

    ```python
    # pip install google-cloud-aiplatform
    import vertexai
    from vertexai.language_models import TextEmbeddingModel

    vertexai.init(project="PROJECT_ID", location="LOCATION")

    model = TextEmbeddingModel.from_pretrained("textembedding-gecko@003")
    embeddings = model.get_embeddings(["What is the purpose of a vector database?"])

    print(embeddings[0].values)
    ```

=== "REST API"

    **Chat completions**

    The following code shows how to convert an OpenAI chat completion request to a Vertex AI request using the REST API.

    ```shell
    curl https://api.openai.com/v1/chat/completions \
      -H "Content-Type: application/json" \
      -H "Authorization: Bearer $OPENAI_API_KEY" \
      -d '{
        "model": "gpt-3.5-turbo",
        "messages": [
          {
            "role": "user",
            "content": "What is the purpose of a vector database?"
          }
        ]
      }'
    ```

    ```shell
    curl -X POST \
        -H "Authorization: Bearer $(gcloud auth print-access-token)" \
        -H "Content-Type: application/json" \
        https://us-central1-aiplatform.googleapis.com/v1/projects/PROJECT_ID/locations/LOCATION/publishers/google/models/chat-bison@002:predict \
        -d '{
          "instances": [
            {
              "messages": [
                {
                  "author": "user",
                  "content": "What is the purpose of a vector database?"
                }
              ]
            }
          ]
        }'
    ```

    **Embeddings**

    The following code shows how to convert an OpenAI embeddings request to a Vertex AI request using the REST API.

    ```shell
    curl https://api.openai.com/v1/embeddings \
      -H "Content-Type: application/json" \
      -H "Authorization: Bearer $OPENAI_API_KEY" \
      -d '{
        "input": "What is the purpose of a vector database?",
        "model": "text-embedding-ada-002"
      }'
    ```

    ```shell
    curl -X POST \
        -H "Authorization: Bearer $(gcloud auth print-access-token)" \
        -H "Content-Type: application/json" \
        https://us-central1-aiplatform.googleapis.com/v1/projects/PROJECT_ID/locations/LOCATION/publishers/google/models/textembedding-gecko@003:predict \
        -d '{
          "instances": [
            {
              "content": "What is the purpose of a vector database?"
            }
          ]
        }'
    ```

## 🔗 Model comparison

Vertex AI offers a variety of models to suit different needs. The following table shows the recommended Vertex AI model for common OpenAI models.

| OpenAI Model | Vertex AI Model | Notes |
| :--- | :--- | :--- |
| `gpt-4` | `gemini-1.0-pro` | Gemini 1.0 Pro is a powerful multimodal model suitable for a wide range of complex reasoning tasks involving text and images. |
| `gpt-3.5-turbo` | `chat-bison@002` | PaLM 2 for Chat (`chat-bison`) is optimized for multi-turn chat conversations. |
| `text-embedding-ada-002` | `textembedding-gecko@003` | The Gecko text embedding model is optimized for retrieval-augmented generation (RAG) and other tasks requiring high-quality vector embeddings. |

For a complete list of available models, see [Discover generative AI models](https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models).

## 🔗 Parameter comparison

While many parameters are similar between the OpenAI and Vertex AI APIs, there are some key differences in naming and behavior.

| OpenAI Parameter | Vertex AI Parameter | Notes |
| :--- | :--- | :--- |
| `model` | `model` | Specifies the model to use. |
| `messages` | `messages` or `instances` | The prompt or conversation history. Vertex AI uses `messages` for chat models and `instances` for other model types. |
| `max_tokens` | `maxOutputTokens` | The maximum number of tokens to generate in the response. |
| `temperature` | `temperature` | Controls the randomness of the output. A higher value results in more creative responses. |
| `top_p` | `topP` | The cumulative probability of tokens to consider for sampling. |
| `n` | `candidateCount` | The number of response candidates to generate. |
| `stop` | `stopSequences` | A list of strings that will cause the model to stop generating tokens. |
| `presence_penalty` | Not directly supported | You can influence presence by carefully crafting your prompt. |
| `frequency_penalty` | Not directly supported | You can influence frequency by carefully crafting your prompt. |

## 📚 What's next

*   Learn how to [migrate from OpenAI chat completions](https://cloud.google.com/vertex-ai/generative-ai/docs/migrate/openai/chat-completions).
*   Learn how to [migrate from OpenAI embeddings](https://cloud.google.com/vertex-ai/generative-ai/docs/migrate/openai/embeddings).
*   Learn about [LangChain on Vertex AI](https://cloud.google.com/vertex-ai/docs/generative-ai/extensions/langchain).
*   Learn about [authentication for Vertex AI](https://cloud.google.com/vertex-ai/docs/generative-ai/auth-setup).