# Migrate from OpenAI to Vertex AI

This document provides side-by-side code examples to help you migrate your generative AI applications from the OpenAI API to the Google Cloud Vertex AI API. Vertex AI offers a comprehensive platform for building, deploying, and scaling machine learning models, including a wide range of foundation models for generative AI tasks.

By following these examples, you can adapt your existing code to leverage Google's powerful and flexible AI infrastructure.

```mermaid
flowchart LR
    A[Before you begin] --> B[Initialize the Vertex AI SDK]
    B --> C[Run migration examples]
    C --> D[Clean up]

    click A "#before-you-begin"
    click B "#initialize-the-vertex-ai-sdk"
    click C "#run-migration-examples"
    click D "#cleaning-up"
```

## 📚 Objective

This tutorial walks you through several examples of how to migrate your existing code from the OpenAI API to the Vertex AI API.

You will learn how to perform the following tasks using both APIs:
*   Generate text from a text prompt
*   Create a conversational chat
*   Generate text from image and text inputs (multimodal)
*   Use function calling
*   Generate embeddings

## 📚 Costs

This tutorial uses billable components of Google Cloud, including:
*   Vertex AI

Learn about [Vertex AI pricing](https://cloud.google.com/vertex-ai/pricing), and use the [Pricing Calculator](https://cloud.google.com/products/calculator/) to generate a cost estimate based on your projected usage.

## ⚙️ Before you begin
<a name="before-you-begin"></a>

???+ "Before you begin"

    1. In the Google Cloud console, on the project selector page, select or [create a Google Cloud project](https://cloud.google.com/resource-manager/docs/creating-managing-projects).

    2. Make sure that billing is enabled for your Google Cloud project. [Learn how to check if billing is enabled on a project](https://cloud.google.com/billing/docs/how-to/verify-billing-enabled).

    3. Enable the Vertex AI API.

        [Enable the API](https://console.cloud.google.com/flows/enableapi?apiid=aiplatform.googleapis.com){: .md-button}

    4. You need the Owner or Editor role in your project. For more information, see [Access control for Vertex AI](https://cloud.google.com/vertex-ai/docs/general/access-control).

    5. Install the Vertex AI SDK for Python.

        ```bash
        pip install google-cloud-aiplatform
        ```

    6. Authenticate with Google Cloud.

        ```bash
        gcloud auth application-default login
        ```

    7. Set your project ID.

        ```bash
        gcloud config set project YOUR_PROJECT_ID
        ```

    !!! tip "Troubleshooting"
        If you encounter issues with code snippets or setup, refer to the [Troubleshooting Guide](https://cloud.google.com/vertex-ai/docs/general/troubleshooting?component=any).

## 💻 Run migration examples
<a name="run-migration-examples"></a>

The following examples demonstrate how to migrate common generative AI tasks from OpenAI to Vertex AI.

### Initialize the Vertex AI SDK
<a name="initialize-the-vertex-ai-sdk"></a>

When using the Vertex AI SDK for Python, you initialize it with your Google Cloud project ID and location. All subsequent calls to the SDK use this project and location.

```python
import vertexai
import os

# TODO(developer): Update and un-comment below lines
# project_id = "YOUR_PROJECT_ID"
# os.environ["GOOGLE_CLOUD_PROJECT"] = project_id

vertexai.init(project=project_id, location="us-central1")
```

=== "Text generation"

    This example shows how to generate text from a text-only prompt.

    **OpenAI**
    ```python
    import os
    from openai import OpenAI

    # TODO(developer): Update and un-comment below lines
    # os.environ["OPENAI_API_KEY"] = "YOUR_API_KEY"
    client = OpenAI()

    response = client.completions.create(
        model="gpt-3.5-turbo-instruct",
        prompt="What is a large language model?",
    )
    print(response)
    ```

    **Vertex AI**
    ```python
    from vertexai.generative_models import GenerativeModel

    model = GenerativeModel(model_name="gemini-1.0-pro-002")

    response = model.generate_content("What is a large language model?")
    print(response)
    ```

=== "Chat"

    This example shows how to create a conversational chat that responds to multiple turns of a conversation.

    **OpenAI**
    ```python
    import os
    from openai import OpenAI

    # TODO(developer): Update and un-comment below lines
    # os.environ["OPENAI_API_KEY"] = "YOUR_API_KEY"
    client = OpenAI()

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "user", "content": "Hello! How are you?"},
            {"role": "assistant", "content": "I am doing great. How can I help you?"},
            {"role": "user", "content": "What is a large language model?"},
        ],
    )
    print(response)
    ```

    **Vertex AI**
    ```python
    from vertexai.generative_models import GenerativeModel

    model = GenerativeModel(model_name="gemini-1.0-pro-002")
    chat = model.start_chat()

    response = chat.send_message("Hello! How are you?")
    print(response)

    response = chat.send_message("What is a large language model?")
    print(response)
    ```

=== "Multimodal"

    This example shows how to generate text from both image and text inputs in the same prompt.

    **OpenAI**
    ```python
    import os
    from openai import OpenAI

    # TODO(developer): Update and un-comment below lines
    # os.environ["OPENAI_API_KEY"] = "YOUR_API_KEY"
    client = OpenAI()

    response = client.chat.completions.create(
        model="gpt-4-turbo",
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "What's in this image?"},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": "https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/PNG_transparency_demonstration_1.png/640px-PNG_transparency_demonstration_1.png",
                        },
                    },
                ],
            }
        ],
        max_tokens=300,
    )
    print(response)
    ```

    **Vertex AI**
    ```python
    import requests
    from vertexai.generative_models import GenerativeModel, Part

    model = GenerativeModel(model_name="gemini-1.0-pro-vision-001")

    image_url = "https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/PNG_transparency_demonstration_1.png/640px-PNG_transparency_demonstration_1.png"
    image_content = requests.get(image_url).content
    image = Part.from_data(data=image_content, mime_type="image/png")

    prompt = "What's in this image?"

    response = model.generate_content([image, prompt])
    print(response)
    ```

=== "Function calling"

    This example shows how to use function calling to get structured data outputs from a model.

    **OpenAI**
    ```python
    import json
    import os
    from openai import OpenAI

    # TODO(developer): Update and un-comment below lines
    # os.environ["OPENAI_API_KEY"] = "YOUR_API_KEY"
    client = OpenAI()

    def get_current_weather(location, unit="fahrenheit"):
        """Get the current weather in a given location"""
        if "tokyo" in location.lower():
            return json.dumps({"location": "Tokyo", "temperature": "10", "unit": unit})
        elif "san francisco" in location.lower():
            return json.dumps(
                {"location": "San Francisco", "temperature": "72", "unit": unit}
            )
        elif "paris" in location.lower():
            return json.dumps({"location": "Paris", "temperature": "22", "unit": unit})
        else:
            return json.dumps({"location": location, "temperature": "unknown"})

    messages = [{"role": "user", "content": "What's the weather like in San Francisco?"}]
    tools = [
        {
            "type": "function",
            "function": {
                "name": "get_current_weather",
                "description": "Get the current weather in a given location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "The city and state, e.g. San Francisco, CA",
                        },
                        "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]},
                    },
                    "required": ["location"],
                },
            },
        }
    ]
    response = client.chat.completions.create(
        model="gpt-3.5-turbo-0125",
        messages=messages,
        tools=tools,
        tool_choice="auto",
    )
    print(response)
    ```

    **Vertex AI**
    ```python
    from vertexai.generative_models import FunctionDeclaration, GenerativeModel, Tool

    get_current_weather_func = FunctionDeclaration(
        name="get_current_weather",
        description="Get the current weather in a given location",
        parameters={
            "type": "object",
            "properties": {
                "location": {
                    "type": "string",
                    "description": "The city and state, e.g. San Francisco, CA",
                },
            },
            "required": [
                "location",
            ],
        },
    )

    weather_tool = Tool(
        function_declarations=[get_current_weather_func],
    )

    model = GenerativeModel(
        model_name="gemini-1.0-pro-002",
        tools=[weather_tool],
    )

    response = model.generate_content("What's the weather like in San Francisco?")
    print(response)
    ```

=== "Embeddings"

    This example shows how to generate embeddings for a given text.

    **OpenAI**
    ```python
    import os
    from openai import OpenAI

    # TODO(developer): Update and un-comment below lines
    # os.environ["OPENAI_API_KEY"] = "YOUR_API_KEY"
    client = OpenAI()

    response = client.embeddings.create(
        input="What is a large language model?", model="text-embedding-3-small"
    )
    print(response)
    ```

    **Vertex AI**
    ```python
    from vertexai.language_models import TextEmbeddingModel

    model = TextEmbeddingModel.from_pretrained("textembedding-gecko@003")

    response = model.get_embeddings(["What is a large language model?"])
    print(response)
    ```

## ⚙️ Cleaning up
<a name="cleaning-up"></a>

???+ "Steps for cleaning up"

    To avoid incurring charges to your Google Cloud account for the resources used in this tutorial, either delete the project that contains the resources, or keep the project and delete the individual resources.

    1. Go to the project selector page in the Google Cloud console.
    2. Select the project you want to delete.
    3. Click the **Delete** button.
    4. In the dialog, type the project ID, and then click **Shut down** to delete the project.