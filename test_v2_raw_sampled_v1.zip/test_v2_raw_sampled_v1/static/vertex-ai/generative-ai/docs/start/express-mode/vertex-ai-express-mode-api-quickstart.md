# Get started with Express mode using the Vertex AI API

> **Preview**
>
> Express mode is a lightweight, low-latency serving mode for fine-tuned models and custom models. When you deploy a model in Express mode, you can achieve significantly lower latency compared to deploying the same model to a standard Vertex AI endpoint. This feature is in [Preview](https://cloud.google.com/products#product-launch-stages).

## 📚 Overview

This document shows you how to get started with Express mode by sending a chat prompt request to a deployed model using the Vertex AI API.

```mermaid
flowchart LR
    A[Set up your environment] --> B[Send a prompt request] --> C[Clean up resources]

click A "#set-up-your-environment"
click B "#send-a-text-chat-prompt-request"
click C "#clean-up"
```

## ⚙️ Before you begin
<a name="set-up-your-environment"></a>

???+ "Prerequisites"

    **Sign in to Google Cloud**

    1. In the Google Cloud console, on the project selector page, select or [create a Google Cloud project](https://cloud.google.com/resource-manager/docs/creating-managing-projects).
    2. Make sure that billing is enabled for your Google Cloud project. [Learn how to check if billing is enabled on a project](https://cloud.google.com/billing/docs/how-to/verify-billing-enabled).

    **Enable APIs**

    Enable the Vertex AI API.

    [Enable the API](https://console.cloud.google.com/flows/enableapi?apiid=aiplatform.googleapis.com){: .md-button}

    **Create a service account**

    1. In the Google Cloud console, go to the **Service Accounts** page.

        [Go to Service Accounts](https://console.cloud.google.com/iam-admin/serviceaccounts){: .md-button}

    2. Select your project.
    3. Click **Create Service Account**.
    4. In the **Service account name** field, enter a name. The Google Cloud console fills in the **Service account ID** field based on this name.
    5. Optional: In the **Service account description** field, enter a description.
    6. Click **Create and Continue**.
    7. Click the **Select a role** field and select **Vertex AI User**.
    8. Click **Done**.

    **Set environment variables**

    Set the following environment variables. Replace `YOUR_PROJECT_ID` with your project ID, `YOUR_SERVICE_ACCOUNT_ID` with the ID of the service account you just created, and `us-central1` with your preferred region.

    ```bash
    export PROJECT_ID="YOUR_PROJECT_ID"
    export SA_ID="YOUR_SERVICE_ACCOUNT_ID"
    export REGION="us-central1"
    ```

    **Install the client library**

    Install the appropriate client library for your preferred language.

    === "Python"

        ```bash
        pip install google-cloud-aiplatform
        ```

    === "Java"

        Add the following dependency to your `pom.xml` file:
        ```xml
        <dependency>
            <groupId>com.google.cloud</groupId>
            <artifactId>google-cloud-aiplatform</artifactId>
            <version>3.41.0</version>
        </dependency>
        ```

    === "Node.js"

        ```bash
        npm install @google-cloud/aiplatform
        ```

    === "Go"

        ```go
        import "cloud.google.com/go/aiplatform/apiv1"
        ```

    !!! tip "Troubleshooting"
        If you encounter issues with code snippets or setup, refer to the [Troubleshooting Guide](https://cloud.google.com/vertex-ai/docs/general/troubleshooting?component=any).

## 💻 Send a text chat prompt request
<a name="send-a-text-chat-prompt-request"></a>

Use the following samples to send a text chat prompt request to a deployed model in Express mode. Replace `YOUR_EXPRESS_MODE_ENDPOINT_ID` with the ID of your Express mode endpoint.

=== "Python"

    ```python
    import vertexai
    from vertexai.language_models import ChatModel

    def predict_chat_prompt(
        project_id: str,
        endpoint_id: str,
        location: str,
    ) -> str:
        """Predict a response to a chat prompt."""
        vertexai.init(project=project_id, location=location)

        chat_model = ChatModel.from_pretrained("chat-bison@002")

        # Use the Express mode endpoint ID.
        chat = chat_model.start_chat(endpoint_id=endpoint_id)

        response = chat.send_message("Hello")

        return response.text

    if __name__ == "__main__":
        # Replace with your project ID, endpoint ID, and location.
        project_id = "YOUR_PROJECT_ID"
        endpoint_id = "YOUR_EXPRESS_MODE_ENDPOINT_ID"
        location = "us-central1"

        response_text = predict_chat_prompt(project_id, endpoint_id, location)
        print(f"Response: {response_text}")
    ```

=== "Java"

    ```java
    import com.google.cloud.aiplatform.v1.EndpointName;
    import com.google.cloud.aiplatform.v1.PredictionServiceClient;
    import com.google.cloud.aiplatform.v1.PredictionServiceSettings;
    import com.google.gson.JsonArray;
    import com.google.gson.JsonObject;
    import com.google.protobuf.Value;
    import com.google.protobuf.util.JsonFormat;
    import java.io.IOException;
    import java.util.ArrayList;
    import java.util.List;

    public class PredictChatPrompt {

      public static void main(String[] args) throws IOException {
        // Replace with your project ID, endpoint ID, and location.
        String project = "YOUR_PROJECT_ID";
        String endpointId = "YOUR_EXPRESS_MODE_ENDPOINT_ID";
        String location = "us-central1";

        predictChatPrompt(project, endpointId, location);
      }

      public static void predictChatPrompt(String project, String endpointId, String location)
          throws IOException {
        final String endpoint = String.format("%s-aiplatform.googleapis.com:443", location);
        PredictionServiceSettings predictionServiceSettings =
            PredictionServiceSettings.newBuilder().setEndpoint(endpoint).build();

        try (PredictionServiceClient predictionServiceClient =
            PredictionServiceClient.create(predictionServiceSettings)) {
          EndpointName endpointName = EndpointName.ofProjectLocationEndpointName(
              project, location, endpointId);

          JsonObject instance = new JsonObject();
          JsonArray messages = new JsonArray();
          JsonObject message = new JsonObject();
          message.addProperty("author", "user");
          message.addProperty("content", "Hello");
          messages.add(message);
          instance.add("messages", messages);

          List<Value> instances = new ArrayList<>();
          Value.Builder instanceValue = Value.newBuilder();
          JsonFormat.parser().merge(instance.toString(), instanceValue);
          instances.add(instanceValue.build());

          com.google.cloud.aiplatform.v1.PredictResponse response =
              predictionServiceClient.predict(endpointName, instances, Value.newBuilder().build());

          System.out.println("Response: " + response);
        }
      }
    }
    ```

=== "Node.js"

    ```javascript
    const {PredictionServiceClient} = require('@google-cloud/aiplatform');
    const {helpers} = require('@google-cloud/aiplatform');

    async function predictChatPrompt() {
      // Replace with your project ID, endpoint ID, and location.
      const project = 'YOUR_PROJECT_ID';
      const endpointId = 'YOUR_EXPRESS_MODE_ENDPOINT_ID';
      const location = 'us-central1';

      const clientOptions = {
        apiEndpoint: 'us-central1-aiplatform.googleapis.com',
      };

      const predictionServiceClient = new PredictionServiceClient(clientOptions);

      const endpoint = `projects/${project}/locations/${location}/endpoints/${endpointId}`;

      const instance = {
        messages: [
          {
            author: 'user',
            content: 'Hello',
          },
        ],
      };

      const instanceValue = helpers.toValue(instance);
      const instances = [instanceValue];

      const request = {
        endpoint,
        instances,
      };

      const [response] = await predictionServiceClient.predict(request);
      console.log('Response: ', JSON.stringify(response));
    }

    predictChatPrompt();
    ```

=== "Go"

    ```go
    import (
        "context"
        "fmt"
        "log"

        "cloud.google.com/go/aiplatform/apiv1"
        "cloud.google.com/go/aiplatform/apiv1/aiplatformpb"
        "google.golang.org/api/option"
        "google.golang.org/protobuf/types/known/structpb"
    )

    func predictChatPrompt(projectID, endpointID, location string) (*aiplatformpb.PredictResponse, error) {
        ctx := context.Background()
        endpoint := fmt.Sprintf("%s-aiplatform.googleapis.com:443", location)
        client, err := aiplatform.NewPredictionClient(ctx, option.WithEndpoint(endpoint))
        if err != nil {
            return nil, fmt.Errorf("failed to create prediction client: %w", err)
        }
        defer client.Close()

        instance, err := structpb.NewStruct(map[string]interface{}{
            "messages": []interface{}{
                map[string]interface{}{
                    "author":  "user",
                    "content": "Hello",
                },
            },
        })
        if err != nil {
            return nil, fmt.Errorf("failed to create instance struct: %w", err)
        }

        req := &aiplatformpb.PredictRequest{
            Endpoint:  fmt.Sprintf("projects/%s/locations/%s/endpoints/%s", projectID, location, endpointID),
            Instances: []*structpb.Value{structpb.NewStructValue(instance)},
        }

        resp, err := client.Predict(ctx, req)
        if err != nil {
            return nil, fmt.Errorf("failed to predict: %w", err)
        }

        return resp, nil
    }

    func main() {
        // Replace with your project ID, endpoint ID, and location.
        projectID := "YOUR_PROJECT_ID"
        endpointID := "YOUR_EXPRESS_MODE_ENDPOINT_ID"
        location := "us-central1"

        resp, err := predictChatPrompt(projectID, endpointID, location)
        if err != nil {
            log.Fatalf("Prediction failed: %v", err)
        }

        fmt.Printf("Response: %v\n", resp)
    }
    ```

## 🔗 Parameters

The following table shows the parameters for the `chat-bison` model:

| Parameter | Description | Accepted values |
|---|---|---|
| `temperature` | Controls the randomness of the output. | `0.0` - `1.0` |
| `maxOutputTokens` | Maximum number of tokens to generate. | `1` - `2048` |
| `topP` | The cumulative probability of tokens to consider when sampling. | `0.0` - `1.0` |
| `topK` | The number of highest probability tokens to consider when sampling. | `1` - `40` |

## 💻 Sample response

```json
{
  "predictions": [
    {
      "candidates": [
        {
          "author": "1",
          "content": "Hi there! How can I help you today?"
        }
      ],
      "citationMetadata": [
        {
          "citations": []
        }
      ]
    }
  ],
  "deployedModelId": "YOUR_DEPLOYED_MODEL_ID",
  "model": "projects/YOUR_PROJECT_ID/locations/us-central1/models/YOUR_MODEL_ID",
  "modelDisplayName": "YOUR_MODEL_DISPLAY_NAME",
  "modelVersionId": "1"
}
```

## ⚙️ Clean up
<a name="clean-up"></a>

??? "Steps to clean up"

    To avoid incurring unnecessary charges to your Google Cloud account for the resources used in this quickstart, you can delete the endpoint and the model.

    1. In the Google Cloud console, go to the **Vertex AI Endpoints** page.

        [Go to Endpoints](https://console.cloud.google.com/vertex-ai/endpoints){: .md-button}

    2. Select your endpoint and click **Undeploy model from endpoint**.
    3. After the model is undeployed, select the endpoint and click **Delete**.
    4. In the Google Cloud console, go to the **Vertex AI Models** page.

        [Go to Models](https://console.cloud.google.com/vertex-ai/models){: .md-button}

    5. Select your model and click **Delete**.

## 🔗 What's next

*   Learn how to [tune a foundation model](https://cloud.google.com/vertex-ai/docs/generative-ai/models/tune-models).
*   Learn about [responsible AI best practices and Vertex AI's safety filters](https://cloud.google.com/vertex-ai/docs/generative-ai/learn/responsible-ai).