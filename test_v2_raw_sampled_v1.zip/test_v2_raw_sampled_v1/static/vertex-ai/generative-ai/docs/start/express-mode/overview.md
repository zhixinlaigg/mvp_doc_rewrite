# Get started with Express mode in Vertex AI Studio

Express mode in Vertex AI Studio is a streamlined experience for generative AI that is designed for quick experimentation and prototyping. This document provides an overview of Express mode and shows you how to get started.

## 📚 What is Express mode?

Express mode is a simplified interface within Vertex AI Studio that offers a curated set of features for ease of use. It allows you to quickly test prompts and generate content without the complexity of the full Vertex AI Studio experience. Express mode is ideal for beginners or for users who need to rapidly iterate on ideas.

## 📚 When to use Express mode

Choose the interface that best suits your needs. The following table compares the key features of Express mode and the standard Vertex AI Studio.

| Feature | Express mode | Standard Vertex AI Studio |
| :--- | :--- | :--- |
| **Primary Use Case** | Quick experimentation, prompt ideation, and learning generative AI concepts. | Developing, testing, and deploying production-ready applications. |
| **Target User** | Beginners, prompt engineers, and users new to Google Cloud. | Developers, data scientists, and ML engineers. |
| **Interface** | Simplified, with fewer parameters and a guided workflow. | Comprehensive, with full control over models, parameters, and versions. |
| **Model Tuning** | Not available. | Full support for tuning foundation models. |
| **Model Selection** | A curated list of models optimized for general tasks. | Access to a wide range of foundation models and versions. |

## ⚙️ Get started with Express mode

The following workflow shows how to start using Express mode in Vertex AI Studio.

```mermaid
flowchart LR
    A[Go to Vertex AI Studio] --> B[Select Express mode]
    B --> C[Write a prompt]
    C --> D[Generate content]

    click A "#step-1-go-to-vertex-ai-studio"
    click B "#step-2-select-express-mode"
    click C "#step-3-write-a-prompt"
    click D "#step-4-generate-content"
```

???+ "Steps to use Express mode"

    <a name="step-1-go-to-vertex-ai-studio"></a>
    **1. Go to Vertex AI Studio**

    In the Google Cloud console, navigate to the Vertex AI Studio page.

    [Go to Vertex AI Studio](https://console.cloud.google.com/vertex-ai/generative){: .md-button}

    <a name="step-2-select-express-mode"></a>
    **2. Select Express mode**

    In the Vertex AI Studio navigation menu, click **Express**. If you don't see this option, it might not be enabled for your project.

    <figure style="text-align: center;">
      <img src="https://cloud.google.com/static/vertex-ai/generative-ai/docs/start/express-mode/images/express-mode-ui.png" alt="The Express mode user interface in Vertex AI Studio." style="max-width: 100%; border-radius: 8px;">
      <figcaption>The Express mode user interface.</figcaption>
    </figure>

    <a name="step-3-write-a-prompt"></a>
    **3. Write a prompt**

    In the prompt area, enter the instructions for the model. A prompt is the text you provide to the generative model to elicit a specific response. For example: `Write a poem about a robot who dreams of flying.`

    <a name="step-4-generate-content"></a>
    **4. Generate content**

    After writing your prompt and selecting a model, click **Generate**. The model's response appears in the output area. You can then refine your prompt and generate again to improve the results.

## 🔗 What's next

*   Learn more about the [standard Vertex AI Studio](/vertex-ai/docs/generative-ai/studio/overview).
*   Explore how to [tune a foundation model](/vertex-ai/docs/generative-ai/models/tune-models).