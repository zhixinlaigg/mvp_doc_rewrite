# Try it: Send a text prompt to Gemini without an account using Vertex AI Studio

In this quickstart, you use Vertex AI Studio to send a prompt to the Gemini API without registering for a Google Cloud account. Vertex AI Studio provides features that allow you to design, test, and manage prompts for Google's [Gemini](../express-mode/overview.md) large language model (LLM).

In this quickstart, you will:

*   Send a freeform text prompt to the Gemini API.
*   View the code used to generate the response.

```mermaid
flowchart LR
    A[Open Vertex AI Studio] --> B[Enter prompt]
    B --> C[Submit and view response]
    C --> D[View the code]

click A "#test-gemini-using-a-prompt"
click B "#test-gemini-using-a-prompt"
click C "#test-gemini-using-a-prompt"
click D "#test-gemini-using-a-prompt"
```

## 📚 Features available without a Google Cloud account
<a name="features-available-without-a-google-cloud-account"></a>

Access to freeform text prompts is available without a Google Cloud account. When you use Vertex AI Studio without signing in, some features are not available compared to using it with a Google Cloud free trial or a full account. To begin, you must accept the Vertex AI Studio Terms of Service in the Google Cloud console.

The following table compares the features available across different access levels.

| | Use without a Google Cloud account | Use with a Google Cloud free trial account | Use with an existing Google Cloud account |
| :--- | :--- | :--- | :--- |
| **Sign in required** | No | Yes | Yes |
| **Queries per minute (QPM)** | 2 QPM for all multimodal models | See quota limits | See quota limits |
| **Credits offered** | $0 | Up to $300 for 90 days | $0 |
| **Prompt gallery** | No | Yes | Yes |
| **Prompt designer** | Yes | Yes | Yes |
| **Save prompts** | No | Yes | Yes |
| **Prompt history** | No | Yes | Yes |
| **Advanced parameters** | No | No | Yes |
| **Tuning** | No | No | Yes |
| **API usage** | No | Yes | Yes |
| **Billing required** | No | No | Yes |
| **How to get started** | [Go to Vertex AI Studio](https://console.cloud.google.com/vertex-ai/generative/multimodal/create/text){: .md-button} | [Sign up for a free trial](https://console.cloud.google.com/freetrial?redirectPath=/vertex-ai/generative){: .md-button} | [Try Vertex AI Studio in your console](https://console.cloud.google.com/vertex-ai/generative){: .md-button} |

This quickstart provides instructions for accessing Vertex AI Studio without an account. You can also complete this quickstart using the free trial or an existing account.

## 📚 What is a prompt?
<a name="what-is-a-prompt"></a>

A prompt is a natural language request submitted to a language model to generate a response. A good prompt can contain questions, instructions, contextual information, and examples to guide the model. After the model receives a prompt, it can generate text, code, images, and more, depending on the model type.

For example, a simple prompt could be:
`"Summarize the following text in three sentences: <text to summarize>"`

## ⚙️ Test Gemini using a prompt
<a name="test-gemini-using-a-prompt"></a>

Vertex AI Studio lets you test text and multimodal prompts using a variety of Gemini models. In this section, you'll create a text prompt that asks the model to generate names for a flower shop.

!!! tip "Troubleshooting"
    If you encounter issues with Vertex AI Studio, refer to the [Troubleshooting Guide](https://cloud.google.com/vertex-ai/docs/general/troubleshooting?component=any).

???+ "Steps to test a prompt in Vertex AI Studio"

    1.  **Open Vertex AI Studio and create a prompt.**

        [Open Vertex AI Studio](https://console.cloud.google.com/vertex-ai/studio/multimodal){: .md-button}

    2.  **Enter your prompt.**
        
        In the prompt box, enter the following text:
        
        `What are some possible names for a flower shop that sells bouquets of dried flowers?`

    3.  **Submit the prompt and view the response.**
        
        Click **Submit**. The output appears in the **Response** box.

    4.  **View the code.**
        
        To view the Vertex AI API code used to generate the response, click code**Get code**. In the **Get code** panel, you can choose your preferred programming language to see the code sample for the prompt.
        
        **Note:** Opening the sample Python code in a Colab Enterprise notebook is not available without an account.

## 🔗 What's next
<a name="whats-next"></a>

*   See an [introduction to prompt design](https://cloud.google.com/vertex-ai/docs/generative-ai/learn/introduction-prompt-design).
*   Learn about designing [text prompts](https://cloud.google.com/vertex-ai/docs/generative-ai/design/text-prompts) and [text chat prompts](https://cloud.google.com/vertex-ai/docs/generative-ai/design/chat-prompts).
*   Learn about [streaming responses from a model](https://cloud.google.com/vertex-ai/docs/generative-ai/start/stream-multimodal-prompts).