# Quickstart: Deploy your Vertex AI Studio prompt as a web application

> **Preview**
>
> This feature is subject to the "Pre-GA Offerings Terms" in the General Service Terms section of the [Service Specific Terms](/terms/service-terms#1). Pre-GA features are available "as is" and might have limited support. For more information, see the [launch stage descriptions](/products#product-launch-stages).

In Vertex AI Studio, you can design and iterate on your prompts and compare results from different configurations and models. After you finish engineering your prompt, you can deploy it as a web application to share with collaborators or target users for testing. The web application is hosted on Cloud Run and is available outside the Google Cloud console.

In this quickstart, you will:

*   Create a prompt with prompt variables.
*   Deploy your prompt as a web application.
*   Monitor deployment progress and test the deployed application.
*   Update and re-deploy your prompt.
*   Test prompt submission with multimodal support.

```mermaid
flowchart LR
    A[Create a prompt with variables] --> B[Deploy the prompt as a web app]
    B --> C[Monitor deployment status and test]
    C --> D[Update and re-deploy the prompt]
    D --> E[Test with multimodal content]

    click A "#create-a-prompt-with-variables"
    click B "#deploy-your-prompt-as-a-web-application"
    click C "#monitor-the-deployment-status"
    click D "#update-and-re-deploy-your-prompt"
    click E "#insert-multimodal-content"
```

## ⚙️ Before you start
<a name="before-you-start"></a>

???+ "Prerequisites"

    If you have never used Vertex AI Studio before, you can follow the [Vertex AI Studio quickstart guide](quickstart.md) or take the [Google Cloud Skills Boost course](https://www.cloudskillsboost.google/course_templates/552) to learn the basics.

    For this guide, ensure you have the following:
    1.  A Google Cloud project with billing enabled.
    2.  The Vertex AI API enabled.

!!! tip "Troubleshooting"
    If you encounter issues with setup or permissions, refer to the [Troubleshooting Guide for Vertex AI](https://cloud.google.com/vertex-ai/docs/general/troubleshooting?component=any).

## 📚 Additional permissions required
<a name="additional-permissions-required"></a>

To deploy your prompt, you need the following permissions in addition to the standard permissions for using Vertex AI Studio.

| Action | Required permissions | Purpose |
|---|---|---|
| Enable additional APIs | `serviceusage.services.enable` | Enable the following APIs:<ul><li>Cloud Run Admin API (`run.googleapis.com`)</li><li>Artifact Registry API (`artifactregistry.googleapis.com`)</li><li>Cloud Build API (`cloudbuild.googleapis.com`)</li><li>Cloud Logging API (`logging.googleapis.com`)</li></ul> |
| Grant permissions to service accounts | `resourcemanager.projects.setIamPolicy` | Grant the [Compute Engine default service account](/compute/docs/access/service-accounts#default_service_account) the following roles:<ul><li>[Vertex AI Service Agent](/vertex-ai/docs/general/access-control#aiplatform.serviceAgent) (`roles/aiplatform.serviceAgent`)</li><li>[Cloud Build Service Account](/iam/docs/understanding-roles#cloudbuild.builds.builder) (`roles/cloudbuild.builds.builder`)</li></ul> |
| Deploy specific permissions | <ul><li>`storage.buckets.create`</li><li>`run.services.create`</li><li>`artifactregistry.repositories.create`</li><li>`run.services.setIamPolicy`</li></ul> | During deployment, source code is uploaded to a Cloud Storage bucket and then deployed to a new Cloud Run service. The `artifactregistry.repositories.create` permission is required to create a repository for the container image. The `run.services.setIamPolicy` permission is required to make the service publicly accessible. |

If you are the owner of your project, you don't need to take additional actions; just follow the guides in Vertex AI Studio. If you are not the project owner, ask your project administrator to perform the first two actions and then grant you the **Editor** (`roles/editor`) and **Cloud Run Admin** (`roles/run.admin`) roles.

## ⚙️ Deploy and manage your web application
<a name="deploy-and-manage-your-web-application"></a>

???+ "Step-by-step guide to deploy and test your prompt"

    **Create a prompt with prompt variables**
    <a name="create-a-prompt-with-variables"></a>

    1. Navigate to the [create prompt page](https://console.cloud.google.com/vertex-ai/studio/multimodal) in Vertex AI Studio.
    2. In the prompt input box, click **data_object Add variable**.
    3. In the **Manage prompt variables** dialog, enter a variable name, provide a value, and click **Apply**.

    <figure style="text-align: center;">
      <img src="../images/deploy/02-prompt-variable-dialog.png" alt="Manage prompt variables dialog" style="max-width: 100%; border-radius: 8px;">
      <figcaption>The "Manage prompt variables" dialog.</figcaption>
    </figure>

    4. In the prompt input box, compose the prompt using the variable you created. For example, you can enable **Grounding with Google Search** and add "Always get current weather from the web" as the system instructions.

    **Deploy your prompt as a web application**
    <a name="deploy-your-prompt-as-a-web-application"></a>

    1. To deploy your prompt, click the **Build with code** button in the top right corner, and then select **Deploy as app**.

    <figure style="text-align: center;">
      <img src="../images/deploy/04-click-build-with-code-button.png" alt="Click build with code button and click deploy as app" style="max-width: 100%; border-radius: 8px;">
      <figcaption>Deploy the prompt from the "Build with code" menu.</figcaption>
    </figure>

    **Save the prompt**

    A dialog appears, prompting you to save the prompt, which is required before deployment. After the prompt is saved, the deployment dialog opens automatically.

    <figure style="text-align: center;">
      <img src="../images/deploy/05-save-prompt.png" alt="Save prompt first before deployment" style="max-width: 100%; border-radius: 8px;">
      <figcaption>Save the prompt before deployment.</figcaption>
    </figure>

    > **Note:** Saving your prompt in a region for the first time can take 2-3 minutes. A warning box appears after 1 minute. This is an expected one-time operation. Subsequent saves in the same project and region will take only a few seconds.

    **Enable APIs and grant permissions for the first deployment**

    1. If this is your first deployment, a dialog appears for enabling required APIs. Click **Enable required APIs**.
    2. After the APIs are enabled, the **Create a web app** dialog appears. Since access control is not supported in Public Preview, all deployed applications allow public access. **Don't include sensitive or personally identifiable information (PII) in your prompt.**
    3. Check the **I understand this app will be deployed publicly** checkbox, and then click **Create app**.
    4. If this is your first deployment, another dialog appears asking you to grant the required roles to the service account. Click **Grant all** to proceed.

    > **Note:** If you don't have permission to enable APIs or grant access, ask your project administrator to grant the necessary permissions. See [Additional permissions required](#-additional-permissions-required) for more details.

    **Deployment starts**

    Vertex AI Studio creates a zip file containing the web application's source code and uploads it to a Cloud Storage bucket. After deployment starts, the **Manage web app** dialog appears with information about your deployment, including the application's name, last deployment time, and status.

    <figure style="text-align: center;">
      <img src="../images/deploy/10-manage-app-dialog.png" alt="Manage app dialog" style="max-width: 100%; border-radius: 8px;">
      <figcaption>The "Manage web app" dialog shows deployment details.</figcaption>
    </figure>

    **Monitor the deployment status**
    <a name="monitor-the-deployment-status"></a>

    Deployment takes 2-3 minutes. The status is shown in the **Status** column of the **Manage web app** dialog. If you close this dialog, you can reopen it from the menu under the **Build with code** button.

    Once deployment is complete, the status changes to **Ready**, and an **Open** button appears.

    <figure style="text-align: center;">
      <img src="../images/deploy/12-open-app.png" alt="Open the app button shows up next to the app name" style="max-width: 100%; border-radius: 8px;">
      <figcaption>The "Open" button appears when the app is ready.</figcaption>
    </figure>

    You can also monitor the status from the **Notifications** menu (bell icon). The icon shows a green circle when deployment is successful. Clicking the notification redirects you to the Cloud Run page.

    <figure style="text-align: center;">
      <img src="../images/deploy/14-notification-bell.png" alt="Monitor the status from the notification bell" style="max-width: 100%; border-radius: 8px;">
      <figcaption>Monitor deployment status via the notification bell.</figcaption>
    </figure>

    **Test the deployed application**
    <a name="test-the-deployed-application"></a>

    1.  **Access control and secret key**: Your web application is deployed with **Allow unauthenticated** access enabled. To provide basic protection, the application requires a secret key in the URL. You can find this key in the **Secret Key** column of the **Manage web app** dialog.
    2.  **Open the web application**: Click **Open** in the **Manage web app** dialog. The application opens with the secret key automatically appended to the URL (`?key=SECRET_KEY`).

    <figure style="text-align: center;">
      <img src="../images/deploy/13-web-app.png" alt="Open the web application from the manage app dialog. Secret key is appended to the URL." style="max-width: 100%; border-radius: 8px;">
      <figcaption>The deployed web application with the secret key in the URL.</figcaption>
    </figure>

    3.  **Submit the prompt**: Enter a value for the variable and click **Submit**. The results appear on the right.

    <figure style="text-align: center;">
      <img src="../images/deploy/13-2-web-applications-results.png" alt="Submit the prompt from the web app" style="max-width: 100%; border-radius: 8px;">
      <figcaption>Prompt results in the web application.</figcaption>
    </figure>

    > **Note:** Cloud Run is serverless, so the application container may shut down if inactive. The web app might take a few seconds to load, or a submission might fail if the page has been idle. Refreshing the page usually solves this.

    **Update and re-deploy your prompt**
    <a name="update-and-re-deploy-your-prompt"></a>

    1.  Edit your prompt in Vertex AI Studio (for example, by turning it into a conversation).
    2.  Click the **Build with code** button and select **Manage app** to open the **Manage web app** dialog.
    3.  Click **Update app** to re-deploy your application with the updated prompt.
    4.  A confirmation dialog appears, warning that changes made outside Vertex AI Studio (e.g., in the Cloud Run source editor) will be lost. Click **Confirm** to proceed.
    5.  The update process is similar to the initial deployment. After it's done, open the web application again. You will see the updated UI, such as a conversation interface.

    <figure style="text-align: center;">
      <img src="../images/deploy/20-updated-app.png" alt="The updated app has a chat UI" style="max-width: 100%; border-radius: 8px;">
      <figcaption>The updated application with a chat interface.</figcaption>
    </figure>

    **Insert multimodal content**
    <a name="insert-multimodal-content"></a>

    You can insert inputs like images, videos, audio, and documents into the conversation. Supported input types depend on the selected model. For details, see the [documentation for multimodal support for each model](https://ai.google.dev/gemini-api/docs/models#model-variations).

    1.  To insert a file, click the **clip** icon in the conversation input box.

    <figure style="text-align: center;">
      <img src="../images/deploy/21-multimodal.png" alt="Insert multimodal inputs" style="max-width: 100%; border-radius: 8px;">
      <figcaption>Insert multimodal inputs using the clip icon.</figcaption>
    </figure>

    2.  After providing the input, you can interact with the model.

    <figure style="text-align: center;">
      <img src="../images/deploy/22-multimodal-image.png" alt="Interact with the model using the multimodal inputs" style="max-width: 100%; border-radius: 8px;">
      <figcaption>Interacting with the model using a provided image.</figcaption>
    </figure>

## ⚙️ Advanced Topics
<a name="advanced-topics"></a>

Once you are familiar with the deployment process, you can explore the following actions.

??? "Edit source code in Cloud Run"

    If you want to customize the web application, you can edit its source code in Cloud Run.

    1.  Open the Cloud Run source code page from the **Manage web app** dialog by clicking the **more_vert** icon at the end of the row.
    2.  In the Cloud Run source code page, click **Edit source**.
    3.  After making your changes, click **Save and redeploy**.

    > **Note:** Cloud Run doesn't support version control directly. If you re-deploy from Vertex AI Studio, your changes will be overwritten. To save a version, click **Download ZIP** on the bottom left before re-deploying.

??? "Turn off public access"

    When you no longer need the web application to be publicly accessible, you can disable public access in Cloud Run.

    1.  Open the **Manage Web App** dialog and click the **edit** pencil icon in the **Access Control** column. The Cloud Run security page opens in a new tab.
    2.  On the Security page, select **Use Cloud IAM to authenticate incoming requests** and choose **Require authentication**.
    3.  Click **Save**.

    Your web application will no longer be accessible via its URL and will show an **Error: Forbidden** page.

??? "Turn on public access again"

    To restore public access, clear the **Use Cloud IAM to authenticate incoming requests** checkbox on the Cloud Run Security page and save. Choosing **Allow unauthenticated invocations** might not work if your project is in an organization. See [Authentication in Cloud Run](/run/docs/authenticating/overview) for more details.

??? "Set up local access for development"

    In Public Preview, access control is not yet fully supported. After turning off public access, the only way to access the web application is by setting up a local proxy using `gcloud` commands.

    1.  Open Cloud Shell by clicking the **terminal** icon in the top right corner of the Google Cloud console and authorize it.
    2.  In the **Manage web app** dialog, click the **more_vert** icon and select **Set up local access via Cloud Shell**.
    3.  A command is added to your Cloud Shell. Press **Enter** and wait for it to finish.
    4.  Click the link in the line starting with `Click on the link to preview`. This link only works while the `gcloud` command is running.

    <figure style="text-align: center;">
      <img src="../images/deploy/adv-06-local-access.png" alt="Local access link in Cloud Shell" style="max-width: 100%; border-radius: 8px;">
      <figcaption>The local access link provided in Cloud Shell.</figcaption>
    </figure>

## ⚙️ Common issues
<a name="common-issues"></a>

??? "Authentication error: No secret key"

    If you see this error, it means no secret key is appended to the URL. Open the web application from Vertex AI Studio, or copy the secret key from the **Manage app** dialog and append it to the URL in the format `?key=SECRET_KEY`.

    <figure style="text-align: center;">
      <img src="../images/deploy/error-01-no-secret-key.png" alt="Error for no secret key" style="max-width: 100%; border-radius: 8px;">
      <figcaption>Error message for a missing secret key.</figcaption>
    </figure>

??? "Authentication error: Invalid secret key"

    This error means the key in the URL is invalid. The secret key is unique to each prompt. Ensure you are using the correct key for the specific prompt.

    <figure style="text-align: center;">
      <img src="../images/deploy/error-02-invalid-key.png" alt="Error for invalid key" style="max-width: 100%; border-radius: 8px;">
      <figcaption>Error message for an invalid secret key.</figcaption>
    </figure>

??? "400 Invalid argument: empty input"

    This error occurs if the prompt has input variables, but the chat input is empty. To fix this, type any non-empty content and resubmit.

    <figure style="text-align: center;">
      <img src="../images/deploy/error-03-invalid-input.png" alt="Error for empty content" style="max-width: 100%; border-radius: 8px;">
      <figcaption>Error message for empty chat input.</figcaption>
    </figure>

??? "400 Invalid argument: mimeType is not supported"

    This error occurs if you upload a file type that the model does not support. You must use a file type supported by the model. See the [documentation for multimodal support for each model](https://ai.google.dev/gemini-api/docs/models#model-variations).

    <figure style="text-align: center;">
      <img src="../images/deploy/error-03-invalid-input.png" alt="Error for unsupported mime types" style="max-width: 100%; border-radius: 8px;">
      <figcaption>Error message for an unsupported file type.</figcaption>
    </figure>

## 🔗 Next steps
<a name="next-steps"></a>

*   Explore more features in the [Vertex AI Studio documentation](/vertex-ai/docs/studio/introduction) or the [Introduction to Vertex AI Studio Google Cloud Skills Boost](https://www.cloudskillsboost.google/course_templates/552) course.
*   Learn about [pricing for Cloud Run](/run/pricing).
*   Learn about [authentication in Cloud Run](/run/docs/authenticating/overview).