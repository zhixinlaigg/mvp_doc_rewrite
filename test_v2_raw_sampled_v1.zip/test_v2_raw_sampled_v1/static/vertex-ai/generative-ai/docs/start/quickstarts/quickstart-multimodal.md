# Quickstart: Generate text from multimodal prompts using the Vertex AI Gemini API

This quickstart shows you how to get started with the Vertex AI Gemini API. You will learn how to send multimodal requests—combining text with images or videos—to the `gemini-2.0-flash-001` model and receive text responses.

You can complete this quickstart by using the Vertex AI SDKs for your preferred programming language or by making direct requests using the REST API.

Before you dive into the examples, it's helpful to understand the different ways you can connect to the Gemini API.

| Method | Description | Best for... |
| :--- | :--- | :--- |
| **Vertex AI SDKs** | The primary SDKs for interacting with all Vertex AI services, including Gemini. Provides full integration with Google Cloud authentication (IAM) and other Vertex AI features. | Users building applications deeply integrated with the Google Cloud ecosystem and requiring robust authentication and enterprise features. |
| **REST API** | A direct HTTP endpoint for the Gemini API. Requires manual handling of authentication tokens and request/response bodies. | Users who cannot use an SDK or need to integrate with a language that doesn't have a dedicated SDK. Offers maximum flexibility. |

---

## ⚙️ Before you begin
<a name="before-you-begin"></a>

???+ "Expand to set up your environment"

    **1. Set up your Google Cloud project**

    *   Sign in to your Google Cloud account. If you're new to Google Cloud, [create an account](https://console.cloud.google.com/freetrial) to evaluate how our products perform in real-world scenarios. New customers also get $300 in free credits to run, test, and deploy workloads.

    *   In the Google Cloud console, on the project selector page, select or create a Google Cloud project.

        > **Note**: If you don't plan to keep the resources that you create in this procedure, create a project instead of selecting an existing project. After you finish these steps, you can delete the project, removing all resources associated with the project.

        [Go to project selector](https://console.cloud.google.com/projectselector2/home/dashboard){: .md-button}

    *   Make sure that billing is enabled for your Google Cloud project.

    *   Enable the Vertex AI API.

        [Enable the API](https://console.cloud.google.com/flows/enableapi?apiid=aiplatform.googleapis.com){: .md-button}

    **2. Set up the Google Cloud CLI**

    On your local machine, set up and authenticate with the Google Cloud CLI. The Vertex AI Gemini API uses Identity and Access Management (IAM) for access control.

    *   Install and initialize the Google Cloud CLI.

    *   If you previously installed the gcloud CLI, ensure your `gcloud` components are updated:
        ```bash
        gcloud components update
        ```

    *   To authenticate with the gcloud CLI, generate local Application Default Credentials (ADC):
        ```bash
        gcloud auth application-default login
        ```

    For more information, see [Set up Application Default Credentials](https://cloud.google.com/docs/authentication/provide-credentials-adc#local-dev).

    > **Note:** To avoid providing your project ID and region in every command, you can use `gcloud config set` to set defaults.

    !!! tip "Troubleshooting"
        If you encounter issues with code snippets or setup, refer to the [Troubleshooting Guide](https://cloud.google.com/vertex-ai/docs/general/troubleshooting?component=any).

    **3. Install the SDK or configure environment variables**

    Click the tab for your preferred language or tool to see installation and setup instructions.

    === "Python"

        Install the Vertex AI SDK for Python:
        ```bash
        pip install --upgrade google-cloud-aiplatform
        ```

    === "Go"

        Install the Vertex AI SDK for Go:
        ```bash
        go get cloud.google.com/go/aiplatform/apiv1/aiplatformpb
        ```

    === "Node.js"

        Install the Vertex AI SDK for Node.js:
        ```bash
        npm install @google-cloud/vertexai
        ```

    === "Java"

        Add the following dependency to your `pom.xml` for Maven, or add the appropriate dependency for your build tool.
        ```xml
        <dependencies>
          <dependency>
            <groupId>com.google.cloud</groupId>
            <artifactId>google-cloud-vertexai</artifactId>
            <version>1.7.0</version>
          </dependency>
        </dependencies>
        ```

    === "C#"

        Install the `Google.Cloud.AIPlatform.V1` package from NuGet. Use your preferred method of adding packages to your project. For example, right-click the project in Visual Studio and choose **Manage NuGet Packages...**.

    === "REST"

        Configure your environment variables. Replace `PROJECT_ID` with the ID of your Google Cloud project.
        ```bash
        MODEL_ID="gemini-1.0-pro-vision-001"
        PROJECT_ID="PROJECT_ID"
        ```

---

```mermaid
flowchart LR
    A[Before you begin] --> B(Send a text-only prompt)
    B --> C(Send a text-and-image prompt)
    C --> D(Send a text-and-video prompt)
    D --> E(Clean up)

    click A "#before-you-begin"
    click B "#send-text-prompt"
    click C "#send-text-image-prompt"
    click D "#send-text-video-prompt"
    click E "#clean-up"
```

## ⚙️ Send multimodal prompts to the Gemini API

???+ "Expand to see the tutorial steps"

    After setting up your environment, you can send prompts to the Gemini API. The following examples show how to get a description for a text prompt, an image, and a video.

    **Step 1: Send a text-only prompt**
    <a name="send-text-prompt"></a>

    Use the following code to send a simple text prompt to the API. This example asks for a list of possible names for a specialty flower store.

    === "Python"

        ```python
        import vertexai
        from vertexai.generative_models import GenerativeModel, Part

        def generate_text(project_id: str, location: str) -> str:
            # Initialize Vertex AI
            vertexai.init(project=project_id, location=location)
            # Load the model
            multimodal_model = GenerativeModel("gemini-1.0-pro-001")
            # Query the model
            response = multimodal_model.generate_content(
                [
                    "What's a good name for a flower shop that specializes in selling bouquets of dried flowers?",
                ]
            )
            print(response)
            return response.text


        if __name__ == "__main__":
            generate_text("your-project-id", "us-central1")
        ```

    === "Go"

        ```go
        package main

        import (
        	"context"
        	"fmt"
        	"io"
        	"log"

        	"cloud.google.com/go/aiplatform/apiv1/aiplatformpb"
        	"github.com/googleapis/gax-go/v2"
        	"google.golang.org/api/option"
        )

        func generateContent(w io.Writer, projectID, location, modelName string) error {
        	ctx := context.Background()

        	// The AI Platform services require a regional endpoint.
        	// For more information, see https://cloud.google.com/vertex-ai/docs/general/locations.
        	endpoint := fmt.Sprintf("%s-aiplatform.googleapis.com:443", location)
        	client, err := gax.NewClient(ctx, option.WithEndpoint(endpoint))
        	if err != nil {
        		return fmt.Errorf("unable to create client: %w", err)
        	}
        	defer client.Close()

        	prompt := "What's a good name for a flower shop that specializes in selling bouquets of dried flowers?"

        	req := &aiplatformpb.GenerateContentRequest{
        		Model: fmt.Sprintf("projects/%s/locations/%s/publishers/google/models/%s", projectID, location, modelName),
        		Contents: []*aiplatformpb.Content{
        			{
        				Role: "USER",
        				Parts: []*aiplatformpb.Part{
        					{
        						Data: &aiplatformpb.Part_Text{
        							Text: prompt,
        						},
        					},
        				},
        			},
        		},
        	}

        	resp, err := client.GenerateContent(ctx, req)
        	if err != nil {
        		return fmt.Errorf("unable to generate content: %w", err)
        	}

        	fmt.Fprintf(w, "response: %s\n", resp.Candidates[0].Content.Parts[0].GetText())

        	return nil
        }

        func main() {
        	// TODO: Add your project ID and location.
        	projectID := "your-project-id"
        	location := "us-central1"
        	modelName := "gemini-1.0-pro-001"

        	if err := generateContent(log.Writer(), projectID, location, modelName); err != nil {
        		log.Fatalf("unable to generate content: %v", err)
        	}
        }
        ```

    === "Node.js"

        ```javascript
        const {VertexAI} = require('@google-cloud/vertexai');

        /**
         * TODO(developer): Update these variables before running the sample.
         */
        async function generateContent(
          projectId = 'your-project-id',
          location = 'us-central1',
          model = 'gemini-1.0-pro-001'
        ) {
          // Initialize Vertex with your Cloud project and location
          const vertexAI = new VertexAI({project: projectId, location: location});

          // Instantiate the model
          const generativeModel = vertexAI.getGenerativeModel({
            model: model,
          });

          const prompt =
            "What's a good name for a flower shop that specializes in selling bouquets of dried flowers?";

          const req = {
            contents: [{role: 'user', parts: [{text: prompt}]}],
          };

          const resp = await generativeModel.generateContent(req);
          const contentResponse = await resp.response;
          console.log(JSON.stringify(contentResponse));
        }

        generateContent();
        ```

    === "Java"

        ```java
        import com.google.cloud.vertexai.VertexAI;
        import com.google.cloud.vertexai.api.GenerateContentResponse;
        import com.google.cloud.vertexai.generativeai.ContentMaker;
        import com.google.cloud.vertexai.generativeai.GenerativeModel;
        import com.google.cloud.vertexai.generativeai.ResponseHandler;
        import java.io.IOException;

        public class TextQuickstart {

          public static void main(String[] args) throws IOException {
            // TODO(developer): Replace these variables before running the sample.
            String projectId = "your-google-cloud-project-id";
            String location = "us-central1";
            String modelName = "gemini-1.0-pro-001";

            String output = quickstart(projectId, location, modelName);
            System.out.println(output);
          }

          // Use a text prompt to generate a response.
          public static String quickstart(String projectId, String location, String modelName)
              throws IOException {
            // Initialize client that will be used to send requests. This client only needs
            // to be created once, and can be reused for multiple requests.
            try (VertexAI vertexAI = new VertexAI(projectId, location)) {
              GenerativeModel model = new GenerativeModel(modelName, vertexAI);

              GenerateContentResponse response = model.generateContent(
                  ContentMaker.fromMultiModalData(
                      "What's a good name for a flower shop that specializes in selling bouquets of dried flowers?"));

              return ResponseHandler.getText(response);
            }
          }
        }
        ```

    === "C#"

        ```csharp
        using Google.Cloud.AIPlatform.V1;
        using System;
        using System.Threading.Tasks;

        public class TextInputSample
        {
            public async Task<string> TextInput(
                string projectId = "your-project-id",
                string location = "us-central1",
                string publisher = "google",
                string model = "gemini-1.0-pro-001")
            {

                var predictionServiceClient = new PredictionServiceClientBuilder
                {
                    Endpoint = $"{location}-aiplatform.googleapis.com"
                }.Build();
                string prompt = @"What's a good name for a flower shop that specializes in selling bouquets of dried flowers?";

                var generateContentRequest = new GenerateContentRequest
                {
                    Model = $"projects/{projectId}/locations/{location}/publishers/{publisher}/models/{model}",
                    Contents =
                    {
                        new Content
                        {
                            Role = "USER",
                            Parts =
                            {
                                new Part { Text = prompt }
                            }
                        }
                    }
                };

                GenerateContentResponse response = await predictionServiceClient.GenerateContentAsync(generateContentRequest);

                string responseText = response.Candidates[0].Content.Parts[0].Text;
                Console.WriteLine(responseText);

                return responseText;
            }
        }
        ```

    === "REST"

        ```bash
        curl -X POST \
        -H "Authorization: Bearer $(gcloud auth print-access-token)" \
        -H "Content-Type: application/json" \
        https://us-central1-aiplatform.googleapis.com/v1/projects/${PROJECT_ID}/locations/us-central1/publishers/google/models/${MODEL_ID}:generateContent -d \
        $'{
          "contents": {
            "role": "user",
            "parts": [
              {
                "text": "What\'s a good name for a flower shop that specializes in selling bouquets of dried flowers?"
              }
            ]
          }
        }'
        ```

    **Step 2: Send a text-and-image prompt**
    <a name="send-text-image-prompt"></a>

    Use the following code to send a prompt that includes both text and an image. This example asks the model to describe the image of scones.

    === "Python"

        ```python
        import vertexai
        from vertexai.generative_models import GenerativeModel, Part


        def generate_text_from_image(project_id: str, location: str) -> str:
            # Initialize Vertex AI
            vertexai.init(project=project_id, location=location)
            # Load the model
            multimodal_model = GenerativeModel("gemini-1.0-pro-vision-001")
            # Query the model
            response = multimodal_model.generate_content(
                [
                    Part.from_uri(
                        "gs://generativeai-downloads/images/scones.jpg", mime_type="image/jpeg"
                    ),
                    "what is shown in this image?",
                ]
            )
            print(response)
            return response.text


        if __name__ == "__main__":
            generate_text_from_image("your-project-id", "us-central1")
        ```

    === "Go"

        ```go
        package main

        import (
        	"context"
        	"fmt"
        	"io"
        	"log"

        	"cloud.google.com/go/aiplatform/apiv1/aiplatformpb"
        	"github.com/googleapis/gax-go/v2"
        	"google.golang.org/api/option"
        )

        func generateContentFromImage(w io.Writer, projectID, location, modelName string) error {
        	ctx := context.Background()

        	endpoint := fmt.Sprintf("%s-aiplatform.googleapis.com:443", location)
        	client, err := gax.NewClient(ctx, option.WithEndpoint(endpoint))
        	if err != nil {
        		return fmt.Errorf("unable to create client: %w", err)
        	}
        	defer client.Close()

        	req := &aiplatformpb.GenerateContentRequest{
        		Model: fmt.Sprintf("projects/%s/locations/%s/publishers/google/models/%s", projectID, location, modelName),
        		Contents: []*aiplatformpb.Content{
        			{
        				Role: "USER",
        				Parts: []*aiplatformpb.Part{
        					{
        						Data: &aiplatformpb.Part_FileData{
        							FileData: &aiplatformpb.FileData{
        								MimeType: "image/png",
        								FileUri:  "gs://generativeai-downloads/images/scones.jpg",
        							},
        						},
        					},
        					{
        						Data: &aiplatformpb.Part_Text{
        							Text: "What's in this photo?",
        						},
        					},
        				},
        			},
        		},
        	}

        	resp, err := client.GenerateContent(ctx, req)
        	if err != nil {
        		return fmt.Errorf("unable to generate content: %w", err)
        	}

        	fmt.Fprintf(w, "response: %s\n", resp.Candidates[0].Content.Parts[0].GetText())

        	return nil
        }

        func main() {
        	projectID := "your-project-id"
        	location := "us-central1"
        	modelName := "gemini-1.0-pro-vision-001"

        	if err := generateContentFromImage(log.Writer(), projectID, location, modelName); err != nil {
        		log.Fatalf("unable to generate content: %v", err)
        	}
        }
        ```

    === "Node.js"

        ```javascript
        const {VertexAI} = require('@google-cloud/vertexai');

        async function createNonStreamingMultipartContent(
          projectId = 'your-project-id',
          location = 'us-central1',
          model = 'gemini-1.0-pro-vision-001',
          image = 'gs://generativeai-downloads/images/scones.jpg',
          mimeType = 'image/jpeg'
        ) {
          // Initialize Vertex with your Cloud project and location
          const vertexAI = new VertexAI({project: projectId, location: location});

          // Instantiate the model
          const generativeVisionModel = vertexAI.getGenerativeModel({
            model: model,
          });

          const filePart = {
            fileData: {
              fileUri: image,
              mimeType: mimeType,
            },
          };

          const textPart = {
            text: 'what is shown in this image?',
          };

          const request = {
            contents: [{role: 'user', parts: [filePart, textPart]}],
          };

          // Generate a response
          const response = await generativeVisionModel.generateContent(request);

          // Select the text from the response
          const fullTextResponse =
            response.response.candidates[0].content.parts[0].text;

          console.log(fullTextResponse);
        }

        createNonStreamingMultipartContent();
        ```

    === "Java"

        ```java
        import com.google.cloud.vertexai.VertexAI;
        import com.google.cloud.vertexai.api.GenerateContentResponse;
        import com.google.cloud.vertexai.generativeai.ContentMaker;
        import com.google.cloud.vertexai.generativeai.GenerativeModel;
        import com.google.cloud.vertexai.generativeai.PartMaker;
        import java.io.IOException;

        public class Quickstart {

          public static void main(String[] args) throws IOException {
            // TODO(developer): Replace these variables before running the sample.
            String projectId = "your-google-cloud-project-id";
            String location = "us-central1";
            String modelName = "gemini-1.0-pro-vision-001";

            String output = quickstart(projectId, location, modelName);
            System.out.println(output);
          }

          // Analyzes the provided Multimodal input.
          public static String quickstart(String projectId, String location, String modelName)
              throws IOException {
            // Initialize client that will be used to send requests. This client only needs
            // to be created once, and can be reused for multiple requests.
            try (VertexAI vertexAI = new VertexAI(projectId, location)) {
              String imageUri = "gs://generativeai-downloads/images/scones.jpg";

              GenerativeModel model = new GenerativeModel(modelName, vertexAI);
              GenerateContentResponse response = model.generateContent(ContentMaker.fromMultiModalData(
                  PartMaker.fromMimeTypeAndData("image/png", imageUri),
                  "What's in this photo"
              ));

              return response.toString();
            }
          }
        }
        ```

    === "C#"

        ```csharp
        using Google.Api.Gax.Grpc;
        using Google.Cloud.AIPlatform.V1;
        using System.Text;
        using System.Threading.Tasks;

        public class GeminiQuickstart
        {
            public async Task<string> GenerateContent(
                string projectId = "your-project-id",
                string location = "us-central1",
                string publisher = "google",
                string model = "gemini-1.0-pro-vision-001"
            )
            {
                // Create client
                var predictionServiceClient = new PredictionServiceClientBuilder
                {
                    Endpoint = $"{location}-aiplatform.googleapis.com"
                }.Build();

                // Initialize content request
                var generateContentRequest = new GenerateContentRequest
                {
                    Model = $"projects/{projectId}/locations/{location}/publishers/{publisher}/models/{model}",
                    Contents =
                    {
                        new Content
                        {
                            Role = "USER",
                            Parts =
                            {
                                new Part { Text = "What's in this photo?" },
                                new Part { FileData = new() { MimeType = "image/png", FileUri = "gs://generativeai-downloads/images/scones.jpg" } }
                            }
                        }
                    }
                };

                // Make the request
                GenerateContentResponse response = await predictionServiceClient.GenerateContentAsync(generateContentRequest);

                string responseText = response.Candidates[0].Content.Parts[0].Text;
                return responseText;
            }
        }
        ```

    === "REST"

        ```bash
        curl -X POST \
        -H "Authorization: Bearer $(gcloud auth print-access-token)" \
        -H "Content-Type: application/json" \
        https://us-central1-aiplatform.googleapis.com/v1/projects/${PROJECT_ID}/locations/us-central1/publishers/google/models/${MODEL_ID}:generateContent -d \
        $'{
          "contents": {
            "role": "user",
            "parts": [
              {
              "fileData": {
                "mimeType": "image/jpeg",
                "fileUri": "gs://generativeai-downloads/images/scones.jpg"
                }
              },
              {
                "text": "Describe this picture."
              }
            ]
          }
        }'
        ```

    **Step 3: Send a text-and-video prompt**
    <a name="send-text-video-prompt"></a>

    Use the following code to send a prompt that includes text, audio, and video. This example asks for a description of the provided video file, including important information from the audio track.

    === "Python"

        ```python
        import vertexai
        from vertexai.generative_models import GenerativeModel, Part


        def generate_text_from_video(project_id: str, location: str) -> str:
            # Initialize Vertex AI
            vertexai.init(project=project_id, location=location)
            # Load the model
            video_model = GenerativeModel("gemini-1.0-pro-vision-001")
            # Query the model
            response = video_model.generate_content(
                [
                    Part.from_uri(
                        "gs://cloud-samples-data/generative-ai/video/pixel8.mp4",
                        mime_type="video/mp4",
                    ),
                    "Provide a description of the video. The description should also contain anything important which people say in the video.",
                ]
            )
            print(response)
            return response.text


        if __name__ == "__main__":
            generate_text_from_video("your-project-id", "us-central1")
        ```

    === "Go"

        ```go
        package main

        import (
        	"context"
        	"fmt"
        	"io"
        	"log"

        	"cloud.google.com/go/aiplatform/apiv1/aiplatformpb"
        	"github.com/googleapis/gax-go/v2"
        	"google.golang.org/api/option"
        )

        func generateContentFromVideo(w io.Writer, projectID, location, modelName string) error {
        	ctx := context.Background()

        	endpoint := fmt.Sprintf("%s-aiplatform.googleapis.com:443", location)
        	client, err := gax.NewClient(ctx, option.WithEndpoint(endpoint))
        	if err != nil {
        		return fmt.Errorf("unable to create client: %w", err)
        	}
        	defer client.Close()

        	req := &aiplatformpb.GenerateContentRequest{
        		Model: fmt.Sprintf("projects/%s/locations/%s/publishers/google/models/%s", projectID, location, modelName),
        		Contents: []*aiplatformpb.Content{
        			{
        				Role: "USER",
        				Parts: []*aiplatformpb.Part{
        					{
        						Data: &aiplatformpb.Part_FileData{
        							FileData: &aiplatformpb.FileData{
        								MimeType: "video/mp4",
        								FileUri:  "gs://cloud-samples-data/generative-ai/video/pixel8.mp4",
        							},
        						},
        					},
        					{
        						Data: &aiplatformpb.Part_Text{
        							Text: "Provide a description of the video. The description should also contain anything important which people say in the video.",
        						},
        					},
        				},
        			},
        		},
        	}

        	resp, err := client.GenerateContent(ctx, req)
        	if err != nil {
        		return fmt.Errorf("unable to generate content: %w", err)
        	}

        	fmt.Fprintf(w, "response: %s\n", resp.Candidates[0].Content.Parts[0].GetText())

        	return nil
        }

        func main() {
        	projectID := "your-project-id"
        	location := "us-central1"
        	modelName := "gemini-1.0-pro-vision-001"

        	if err := generateContentFromVideo(log.Writer(), projectID, location, modelName); err != nil {
        		log.Fatalf("unable to generate content: %v", err)
        	}
        }
        ```

    === "Node.js"

        ```javascript
        const {VertexAI} = require('@google-cloud/vertexai');

        async function analyze_video_with_audio(projectId = 'your-project-id') {
          const vertexAI = new VertexAI({project: projectId, location: 'us-central1'});

          const generativeModel = vertexAI.getGenerativeModel({
            model: 'gemini-1.0-pro-vision-001',
          });

          const filePart = {
            file_data: {
              file_uri: 'gs://cloud-samples-data/generative-ai/video/pixel8.mp4',
              mime_type: 'video/mp4',
            },
          };
          const textPart = {
            text: `
            Provide a description of the video.
            The description should also contain anything important which people say in the video.`,
          };

          const request = {
            contents: [{role: 'user', parts: [filePart, textPart]}],
          };

          const resp = await generativeModel.generateContent(request);
          const contentResponse = await resp.response;
          console.log(JSON.stringify(contentResponse));
        }

        analyze_video_with_audio();
        ```

    === "Java"

        ```java
        import com.google.cloud.vertexai.VertexAI;
        import com.google.cloud.vertexai.api.GenerateContentResponse;
        import com.google.cloud.vertexai.generativeai.ContentMaker;
        import com.google.cloud.vertexai.generativeai.GenerativeModel;
        import com.google.cloud.vertexai.generativeai.PartMaker;
        import com.google.cloud.vertexai.generativeai.ResponseHandler;
        import java.io.IOException;

        public class VideoInputWithAudio {

          public static void main(String[] args) throws IOException {
            // TODO(developer): Replace these variables before running the sample.
            String projectId = "your-google-cloud-project-id";
            String location = "us-central1";
            String modelName = "gemini-1.0-pro-vision-001";

            videoAudioInput(projectId, location, modelName);
          }

          // Analyzes the given video input, including its audio track.
          public static String videoAudioInput(String projectId, String location, String modelName)
              throws IOException {
            // Initialize client that will be used to send requests. This client only needs
            // to be created once, and can be reused for multiple requests.
            try (VertexAI vertexAI = new VertexAI(projectId, location)) {
              String videoUri = "gs://cloud-samples-data/generative-ai/video/pixel8.mp4";

              GenerativeModel model = new GenerativeModel(modelName, vertexAI);
              GenerateContentResponse response = model.generateContent(
                  ContentMaker.fromMultiModalData(
                      "Provide a description of the video.\n The description should also "
                          + "contain anything important which people say in the video.",
                      PartMaker.fromMimeTypeAndData("video/mp4", videoUri)
                  ));

              String output = ResponseHandler.getText(response);
              System.out.println(output);

              return output;
            }
          }
        }
        ```

    === "C#"

        ```csharp
        using Google.Cloud.AIPlatform.V1;
        using System;
        using System.Threading.Tasks;

        public class VideoInputWithAudio
        {
            public async Task<string> DescribeVideo(
                string projectId = "your-project-id",
                string location = "us-central1",
                string publisher = "google",
                string model = "gemini-1.0-pro-vision-001")
            {

                var predictionServiceClient = new PredictionServiceClientBuilder
                {
                    Endpoint = $"{location}-aiplatform.googleapis.com"
                }.Build();

                string prompt = @"Provide a description of the video.
        The description should also contain anything important which people say in the video.";

                var generateContentRequest = new GenerateContentRequest
                {
                    Model = $"projects/{projectId}/locations/{location}/publishers/{publisher}/models/{model}",
                    Contents =
                    {
                        new Content
                        {
                            Role = "USER",
                            Parts =
                            {
                                new Part { Text = prompt },
                                new Part { FileData = new() { MimeType = "video/mp4", FileUri = "gs://cloud-samples-data/generative-ai/video/pixel8.mp4" }}
                            }
                        }
                    }
                };

                GenerateContentResponse response = await predictionServiceClient.GenerateContentAsync(generateContentRequest);

                string responseText = response.Candidates[0].Content.Parts[0].Text;
                Console.WriteLine(responseText);

                return responseText;
            }
        }
        ```

    === "REST"

        ```bash
        curl -X POST \
        -H "Authorization: Bearer $(gcloud auth print-access-token)" \
        -H "Content-Type: application/json" \
        https://us-central1-aiplatform.googleapis.com/v1/projects/${PROJECT_ID}/locations/us-central1/publishers/google/models/${MODEL_ID}:generateContent -d \
        $'{
          "contents": {
            "role": "user",
            "parts": [
              {
              "fileData": {
                "mimeType": "video/mp4",
                "fileUri": "gs://cloud-samples-data/generative-ai/video/pixel8.mp4"
                }
              },
              {
                "text": "Provide a description of the video. The description should also contain anything important which people say in the video."
              }
            ]
          }
        }'
        ```

## ⚙️ Clean up
<a name="clean-up"></a>

To avoid incurring charges to your Google Cloud account for the resources used in this quickstart, you can delete the Google Cloud project you created.

Deleting a project has the following effects:

*   Everything in the project is deleted. If you used an existing project for this quickstart, when you delete it, you also delete any other work you've done in it.
*   Custom project IDs are lost. When you created this project, you might have created a custom project ID that you want to use in the future. To preserve the URLs that use the project ID, such as an `appspot.com` URL, delete selected resources inside the project instead of deleting the whole project.

If you plan to explore multiple quickstarts and tutorials, reusing projects can help you avoid exceeding project quota limits.

To delete the project, go to the project selector page in the Google Cloud console:

[Go to project selector](https://console.cloud.google.com/projectselector2/home/dashboard){: .md-button}

## 🔗 What's next

*   Learn more about the [Vertex AI Gemini API](../express-mode/overview.md).
*   Explore the [Google Gen AI SDK reference](../express-mode/overview.md).
*   Learn about calling Vertex AI models by using the OpenAI library.